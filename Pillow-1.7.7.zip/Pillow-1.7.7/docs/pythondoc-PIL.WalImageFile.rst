===========================
The PIL.WalImageFile Module
===========================

The PIL.WalImageFile Module
===========================

**open(filename)** [`# <#PIL.WalImageFile.open-function>`_]
    Load texture from a Quake2 WAL texture file.

    By default, a Quake2 standard palette is attached to the texture. To
    override the palette, use the **putpalette** method.

    *filename*
    Returns:

