=============================
The PIL.FliImagePlugin Module
=============================

The PIL.FliImagePlugin Module
=============================

**FliImageFile** (class) [`# <#PIL.FliImagePlugin.FliImageFile-class>`_]
    Image plugin for the FLI/FLC animation format.

    For more information about this class, see `*The FliImageFile
    Class* <#PIL.FliImagePlugin.FliImageFile-class>`_.

The FliImageFile Class
----------------------

**FliImageFile** (class) [`# <#PIL.FliImagePlugin.FliImageFile-class>`_]
    Image plugin for the FLI/FLC animation format. Use the **seek**
    method to load individual frames.

