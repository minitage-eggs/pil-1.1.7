==============================
The PIL.GimpPaletteFile Module
==============================

The PIL.GimpPaletteFile Module
==============================

**GimpPaletteFile(fp)** (class)
[`# <#PIL.GimpPaletteFile.GimpPaletteFile-class>`_]
    File handler for GIMP's palette format.

    For more information about this class, see `*The GimpPaletteFile
    Class* <#PIL.GimpPaletteFile.GimpPaletteFile-class>`_.

The GimpPaletteFile Class
-------------------------

**GimpPaletteFile(fp)** (class)
[`# <#PIL.GimpPaletteFile.GimpPaletteFile-class>`_]
